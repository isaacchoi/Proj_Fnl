#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>

int main(int argcp, char ** argv) {
	glutInit(&argcp, argv);
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(0,0);

	glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE);

	glutCreateWindow("Hello World");
	GLenum err = glewInit();
	if(GLEW_OK != err)
	{
	}
	fprintf(stdout, "Status: Using GLEW %s\n", glewGetString(GLEW_VERSION));
	glutMainLoop();
	return 0;
}